import type { Metadata } from "next"
import { ComputeOverview } from "@/components/compute/overview"
import { createClient } from "@/lib/supabase-server"

export const metadata: Metadata = {
  title: "Compute | Nubis Cloud Console",
  description: "Manage your virtual machines",
}

export default async function ComputePage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch user's VMs
  const { data: vms } = await supabase
    .from("virtual_machines")
    .select("*")
    .eq("user_id", user?.id)
    .order("created_at", { ascending: false })

  return <ComputeOverview vms={vms || []} />
}

