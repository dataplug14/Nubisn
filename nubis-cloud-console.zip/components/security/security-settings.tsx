"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase-browser"
import { Key, Lock, Shield } from "lucide-react"

const sshKeyFormSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  publicKey: z.string().min(10, {
    message: "Please enter a valid SSH public key.",
  }),
})

const firewallFormSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  ipRange: z.string().min(7, {
    message: "Please enter a valid IP range.",
  }),
})

export function SecuritySettings() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const supabase = createClient()

  const sshKeyForm = useForm<z.infer<typeof sshKeyFormSchema>>({
    resolver: zodResolver(sshKeyFormSchema),
    defaultValues: {
      name: "",
      publicKey: "",
    },
  })

  const firewallForm = useForm<z.infer<typeof firewallFormSchema>>({
    resolver: zodResolver(firewallFormSchema),
    defaultValues: {
      name: "",
      ipRange: "",
    },
  })

  async function onSSHKeySubmit(values: z.infer<typeof sshKeyFormSchema>) {
    setIsSubmitting(true)

    try {
      // Get the current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("User not authenticated")
      }

      // In a real implementation, this would store the SSH key
      // For now, we'll simulate a successful operation

      // Create a new SSH key record in Supabase
      const { error } = await supabase.from("ssh_keys").insert({
        user_id: user.id,
        name: values.name,
        public_key: values.publicKey,
      })

      if (error) {
        throw error
      }

      toast({
        title: "SSH Key Added",
        description: "Your SSH key has been added successfully.",
      })

      // Reset the form
      sshKeyForm.reset()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add SSH key",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  async function onFirewallSubmit(values: z.infer<typeof firewallFormSchema>) {
    setIsSubmitting(true)

    try {
      // Get the current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("User not authenticated")
      }

      // In a real implementation, this would configure the firewall
      // For now, we'll simulate a successful operation

      // Create a new firewall rule record in Supabase
      const { error } = await supabase.from("firewall_rules").insert({
        user_id: user.id,
        name: values.name,
        ip_range: values.ipRange,
      })

      if (error) {
        throw error
      }

      toast({
        title: "Firewall Rule Added",
        description: "Your firewall rule has been added successfully.",
      })

      // Reset the form
      firewallForm.reset()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add firewall rule",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Security Settings</h1>
        <p className="text-muted-foreground">Manage your security settings and preferences.</p>
      </div>

      <Tabs defaultValue="ssh">
        <TabsList>
          <TabsTrigger value="ssh">SSH Keys</TabsTrigger>
          <TabsTrigger value="firewall">Firewall</TabsTrigger>
          <TabsTrigger value="advanced">Advanced Security</TabsTrigger>
        </TabsList>

        <TabsContent value="ssh" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SSH Keys</CardTitle>
              <CardDescription>Manage SSH keys for secure access to your virtual machines.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...sshKeyForm}>
                <form onSubmit={sshKeyForm.handleSubmit(onSSHKeySubmit)} className="space-y-6">
                  <FormField
                    control={sshKeyForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Key Name</FormLabel>
                        <FormControl>
                          <Input placeholder="My Work Laptop" {...field} />
                        </FormControl>
                        <FormDescription>A descriptive name for your SSH key.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={sshKeyForm.control}
                    name="publicKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Public Key</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="ssh-rsa AAAAB3NzaC1yc2E..."
                            className="font-mono text-sm"
                            rows={6}
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Paste your SSH public key here. It usually starts with ssh-rsa or ssh-ed25519.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Adding..." : "Add SSH Key"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Existing SSH Keys</CardTitle>
              <CardDescription>Your stored SSH keys for VM access.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border">
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center space-x-4">
                    <Key className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="font-medium">nubis_macbook</div>
                      <div className="text-xs text-muted-foreground">Added on {new Date().toLocaleDateString()}</div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      toast({
                        title: "SSH Key Removed",
                        description: "Your SSH key has been removed successfully.",
                      })
                    }}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="firewall" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Firewall Rules</CardTitle>
              <CardDescription>Configure firewall rules to control access to your virtual machines.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...firewallForm}>
                <form onSubmit={firewallForm.handleSubmit(onFirewallSubmit)} className="space-y-6">
                  <FormField
                    control={firewallForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rule Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Office Network" {...field} />
                        </FormControl>
                        <FormDescription>A descriptive name for your firewall rule.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={firewallForm.control}
                    name="ipRange"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>IP Range</FormLabel>
                        <FormControl>
                          <Input placeholder="192.168.1.0/24" {...field} />
                        </FormControl>
                        <FormDescription>Enter an IP address or CIDR range.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Adding..." : "Add Firewall Rule"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Existing Firewall Rules</CardTitle>
              <CardDescription>Your configured firewall rules.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border">
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center space-x-4">
                    <Shield className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <div className="font-medium">Allow SSH</div>
                      <div className="text-xs text-muted-foreground">IP Range: 0.0.0.0/0 • Port: 22</div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      toast({
                        title: "Firewall Rule Removed",
                        description: "Your firewall rule has been removed successfully.",
                      })
                    }}
                  >
                    Remove
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Security Settings</CardTitle>
              <CardDescription>Configure advanced security settings for your account.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between space-x-4">
                <div>
                  <h4 className="font-medium">Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security to your account.</p>
                </div>
                <Switch
                  onCheckedChange={(checked) => {
                    toast({
                      title: checked ? "2FA Enabled" : "2FA Disabled",
                      description: checked
                        ? "Two-factor authentication has been enabled."
                        : "Two-factor authentication has been disabled.",
                    })
                  }}
                />
              </div>

              <div className="flex items-center justify-between space-x-4">
                <div>
                  <h4 className="font-medium">Login Notifications</h4>
                  <p className="text-sm text-muted-foreground">Receive email notifications for new login attempts.</p>
                </div>
                <Switch
                  defaultChecked
                  onCheckedChange={(checked) => {
                    toast({
                      title: checked ? "Notifications Enabled" : "Notifications Disabled",
                      description: checked
                        ? "Login notifications have been enabled."
                        : "Login notifications have been disabled.",
                    })
                  }}
                />
              </div>

              <div className="flex items-center justify-between space-x-4">
                <div>
                  <h4 className="font-medium">IP Restriction</h4>
                  <p className="text-sm text-muted-foreground">
                    Restrict access to your account from specific IP addresses.
                  </p>
                </div>
                <Switch
                  onCheckedChange={(checked) => {
                    toast({
                      title: checked ? "IP Restriction Enabled" : "IP Restriction Disabled",
                      description: checked ? "IP restriction has been enabled." : "IP restriction has been disabled.",
                    })
                  }}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  toast({
                    title: "Security Audit",
                    description: "A security audit has been initiated for your account.",
                  })
                }}
              >
                <Lock className="mr-2 h-4 w-4" />
                Run Security Audit
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

