import { redirect } from "next/navigation"
import { LoginForm } from "@/components/auth/login-form"
import { Logo } from "@/components/ui/logo"
import { createClient } from "@/lib/supabase-server"

export default async function Home() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background">
      <div className="w-full max-w-md space-y-8 p-8 rounded-lg border border-border shadow-sm">
        <div className="flex flex-col items-center space-y-2">
          <Logo className="h-12 w-12" />
          <h1 className="text-2xl font-bold">Nubis Cloud Console</h1>
          <p className="text-sm text-muted-foreground">Sign in to your account to continue</p>
        </div>
        <LoginForm />
        <div className="text-center text-sm">
          <p className="text-muted-foreground">
            Need an account?{" "}
            <a href="mailto:hello@usenubis.xyz" className="font-medium text-primary hover:underline">
              Contact Sales
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}

