import type { Metadata } from "next"
import { BillingManagement } from "@/components/billing/billing-management"
import { createClient } from "@/lib/supabase-server"

export const metadata: Metadata = {
  title: "Billing | Nubis Cloud Console",
  description: "Manage your billing and payment information",
}

export default async function BillingPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch billing information
  const { data: billing } = await supabase.from("billing").select("*").eq("user_id", user?.id).single()

  // Fetch payment history
  const { data: payments } = await supabase
    .from("payments")
    .select("*")
    .eq("user_id", user?.id)
    .order("created_at", { ascending: false })

  return <BillingManagement billing={billing || { balance: 0, used: 0 }} payments={payments || []} />
}

