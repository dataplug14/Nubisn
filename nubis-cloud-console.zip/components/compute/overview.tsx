"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AlertCircle, MoreHorizontal, Plus, Power, PowerOff, RefreshCw, Terminal } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface VirtualMachine {
  id: string
  name: string
  status: string
  ip_address: string
  cpu: number
  memory: number
  storage: number
  created_at: string
}

export function ComputeOverview({ vms }: { vms: VirtualMachine[] }) {
  const { toast } = useToast()

  const handleVMAction = (vmId: string, action: string) => {
    toast({
      title: "VM Action",
      description: `${action} action requested for VM ${vmId}`,
    })
    // In a real implementation, this would call the Hetzner API
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Virtual Machines</h1>
        <Button asChild>
          <Link href="/dashboard/compute/create">
            <Plus className="mr-2 h-4 w-4" />
            New VM
          </Link>
        </Button>
      </div>

      {vms.length > 0 ? (
        <div className="space-y-4">
          <div className="rounded-lg border">
            <div className="grid grid-cols-12 gap-4 p-4 text-sm font-medium text-muted-foreground">
              <div className="col-span-3">Name</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-2">IP Address</div>
              <div className="col-span-1">CPU</div>
              <div className="col-span-1">Memory</div>
              <div className="col-span-2">Created</div>
              <div className="col-span-1 text-right">Actions</div>
            </div>

            {vms.map((vm) => (
              <div key={vm.id} className="grid grid-cols-12 gap-4 border-t p-4 text-sm">
                <div className="col-span-3 font-medium">
                  <Link href={`/dashboard/compute/${vm.id}`} className="hover:underline">
                    {vm.name}
                  </Link>
                </div>
                <div className="col-span-2">
                  <div
                    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      vm.status === "running"
                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                        : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                    }`}
                  >
                    {vm.status}
                  </div>
                </div>
                <div className="col-span-2 font-mono">{vm.ip_address}</div>
                <div className="col-span-1">{vm.cpu} vCPU</div>
                <div className="col-span-1">{vm.memory} GB</div>
                <div className="col-span-2 text-muted-foreground">{new Date(vm.created_at).toLocaleDateString()}</div>
                <div className="col-span-1 flex justify-end">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Actions</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/dashboard/compute/${vm.id}`}>View details</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleVMAction(vm.id, "Restart")}>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Restart
                      </DropdownMenuItem>
                      {vm.status === "running" ? (
                        <DropdownMenuItem onClick={() => handleVMAction(vm.id, "Stop")}>
                          <PowerOff className="mr-2 h-4 w-4" />
                          Stop
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem onClick={() => handleVMAction(vm.id, "Start")}>
                          <Power className="mr-2 h-4 w-4" />
                          Start
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem asChild>
                        <Link href={`/dashboard/compute/${vm.id}/console`}>
                          <Terminal className="mr-2 h-4 w-4" />
                          Console
                        </Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>No Virtual Machines</CardTitle>
            <CardDescription>You haven't created any virtual machines yet.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-4 p-6 text-center">
              <div className="rounded-full bg-primary/10 p-3">
                <AlertCircle className="h-6 w-6 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-semibold">Get started with Compute</h3>
                <p className="text-muted-foreground">
                  Create your first virtual machine to start building your cloud infrastructure.
                </p>
              </div>
              <Button asChild>
                <Link href="/dashboard/compute/create">
                  <Plus className="mr-2 h-4 w-4" />
                  Create VM
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

