"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase-browser"

const formSchema = z.object({
  name: z.string().min(3, {
    message: "VM name must be at least 3 characters.",
  }),
  project: z.string().optional(),
  region: z.string({
    required_error: "Please select a region.",
  }),
  image: z.string({
    required_error: "Please select an operating system.",
  }),
  cpu: z.number().min(1).max(32),
  memory: z.number().min(1).max(128),
  storage: z.number().min(10).max(2000),
  ssh_key: z.string().optional(),
})

const regions = [
  { value: "eu-central", label: "Europe (Frankfurt)" },
  { value: "us-east", label: "US East (Virginia)" },
  { value: "us-west", label: "US West (Oregon)" },
  { value: "asia-southeast", label: "Asia (Singapore)" },
]

const images = [
  { value: "ubuntu-22.04", label: "Ubuntu 22.04 LTS" },
  { value: "debian-11", label: "Debian 11" },
  { value: "centos-8", label: "CentOS 8" },
  { value: "windows-2022", label: "Windows Server 2022" },
]

export function CreateVMForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const supabase = createClient()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      project: "",
      region: "eu-central",
      image: "ubuntu-22.04",
      cpu: 2,
      memory: 4,
      storage: 50,
      ssh_key: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)

    try {
      // In a real implementation, this would call the Hetzner API
      // For now, we'll simulate a successful VM creation

      // Get the current user
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        throw new Error("User not authenticated")
      }

      // Create a new VM record in Supabase
      const { data, error } = await supabase
        .from("virtual_machines")
        .insert({
          user_id: user.id,
          name: values.name,
          project_id: values.project || null,
          region: values.region,
          image: values.image,
          cpu: values.cpu,
          memory: values.memory,
          storage: values.storage,
          ssh_key: values.ssh_key || null,
          status: "provisioning",
          ip_address: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        })
        .select()
        .single()

      if (error) {
        throw error
      }

      toast({
        title: "VM Creation Started",
        description: "Your virtual machine is being provisioned.",
      })

      // Redirect to the VM details page
      router.push(`/dashboard/compute/${data.id}`)
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create VM",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const cpuValue = form.watch("cpu")
  const memoryValue = form.watch("memory")
  const storageValue = form.watch("storage")

  // Calculate estimated cost
  const estimatedCost = (cpuValue * 5 + memoryValue * 2 + storageValue * 0.1).toFixed(2)

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="basic">Basic Configuration</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="ssh">SSH & Security</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6 pt-4">
            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>VM Name</FormLabel>
                    <FormControl>
                      <Input placeholder="my-awesome-server" {...field} />
                    </FormControl>
                    <FormDescription>A unique name for your virtual machine.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="project"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Select a project" {...field} />
                    </FormControl>
                    <FormDescription>Assign this VM to a project for better organization.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="region"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Region</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a region" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {regions.map((region) => (
                          <SelectItem key={region.value} value={region.value}>
                            {region.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>Choose the geographic location for your VM.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="image"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Operating System</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an OS" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {images.map((image) => (
                          <SelectItem key={image.value} value={image.value}>
                            {image.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>Select the operating system for your VM.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6 pt-4">
            <FormField
              control={form.control}
              name="cpu"
              render={({ field: { value, onChange } }) => (
                <FormItem>
                  <FormLabel>CPU Cores: {value} vCPU</FormLabel>
                  <FormControl>
                    <Slider min={1} max={32} step={1} value={[value]} onValueChange={(vals) => onChange(vals[0])} />
                  </FormControl>
                  <FormDescription>Select the number of virtual CPU cores.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="memory"
              render={({ field: { value, onChange } }) => (
                <FormItem>
                  <FormLabel>Memory: {value} GB RAM</FormLabel>
                  <FormControl>
                    <Slider min={1} max={128} step={1} value={[value]} onValueChange={(vals) => onChange(vals[0])} />
                  </FormControl>
                  <FormDescription>Select the amount of RAM for your VM.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="storage"
              render={({ field: { value, onChange } }) => (
                <FormItem>
                  <FormLabel>Storage: {value} GB SSD</FormLabel>
                  <FormControl>
                    <Slider min={10} max={2000} step={10} value={[value]} onValueChange={(vals) => onChange(vals[0])} />
                  </FormControl>
                  <FormDescription>Select the amount of SSD storage.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>

          <TabsContent value="ssh" className="space-y-6 pt-4">
            <FormField
              control={form.control}
              name="ssh_key"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SSH Public Key (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="ssh-rsa AAAAB3NzaC1yc2E..."
                      className="font-mono text-sm"
                      rows={6}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Paste your SSH public key for secure access. If not provided, we'll generate one for you.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>
        </Tabs>

        <Card>
          <CardHeader>
            <CardTitle>Summary</CardTitle>
            <CardDescription>Review your VM configuration before creating.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <h4 className="text-sm font-medium">Configuration</h4>
                <ul className="mt-2 space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">Name:</span>
                    <span>{form.getValues("name") || "Not specified"}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">Region:</span>
                    <span>{regions.find((r) => r.value === form.getValues("region"))?.label || "Not specified"}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">OS:</span>
                    <span>{images.find((i) => i.value === form.getValues("image"))?.label || "Not specified"}</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-medium">Resources</h4>
                <ul className="mt-2 space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">CPU:</span>
                    <span>{cpuValue} vCPU</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">Memory:</span>
                    <span>{memoryValue} GB RAM</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-muted-foreground">Storage:</span>
                    <span>{storageValue} GB SSD</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-start space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
            <p className="text-sm font-medium">
              Estimated Cost: <span className="text-lg">₦{estimatedCost}/hour</span>
            </p>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create VM"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  )
}

