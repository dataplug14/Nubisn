import type { Metadata } from "next"
import { SupportCenter } from "@/components/support/support-center"

export const metadata: Metadata = {
  title: "Support | Nubis Cloud Console",
  description: "Get help and support for Nubis Cloud services",
}

export default function SupportPage() {
  return <SupportCenter />
}

