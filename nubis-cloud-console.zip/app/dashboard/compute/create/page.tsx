import type { Metadata } from "next"
import { CreateVMForm } from "@/components/compute/create-vm-form"

export const metadata: Metadata = {
  title: "Create VM | Nubis Cloud Console",
  description: "Create a new virtual machine",
}

export default function CreateVMPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Create Virtual Machine</h1>
        <p className="text-muted-foreground">
          Configure and deploy a new virtual machine to your cloud infrastructure.
        </p>
      </div>
      <CreateVMForm />
    </div>
  )
}

