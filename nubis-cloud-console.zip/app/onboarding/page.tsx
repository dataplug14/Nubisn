import { redirect } from "next/navigation"
import { OnboardingForm } from "@/components/onboarding/onboarding-form"
import { createClient } from "@/lib/supabase-server"
import { checkOnboardingStatus } from "@/lib/onboarding"

export default async function OnboardingPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/")
  }

  // Check if user has already completed onboarding
  const onboardingComplete = await checkOnboardingStatus(session.user.id)

  if (onboardingComplete) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background">
      <div className="w-full max-w-3xl space-y-8 p-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold">Welcome to Nubis Cloud</h1>
          <p className="mt-2 text-muted-foreground">Let's set up your account to get you started.</p>
        </div>
        <OnboardingForm userId={session.user.id} />
      </div>
    </div>
  )
}

