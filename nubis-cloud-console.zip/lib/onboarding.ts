import { createClient } from "@/lib/supabase-server"

export async function checkOnboardingStatus(userId: string): Promise<boolean> {
  const supabase = createClient()

  const { data, error } = await supabase.from("profiles").select("onboarding_completed").eq("id", userId).single()

  if (error || !data) {
    return false
  }

  return data.onboarding_completed === true
}

