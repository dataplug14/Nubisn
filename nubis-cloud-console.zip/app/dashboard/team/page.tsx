import type { Metadata } from "next"
import { TeamManagement } from "@/components/team/team-management"
import { createClient } from "@/lib/supabase-server"

export const metadata: Metadata = {
  title: "Team Management | Nubis Cloud Console",
  description: "Manage your team members and permissions",
}

export default async function TeamPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch team members
  const { data: teamMembers } = await supabase.from("team_members").select("*").eq("owner_id", user?.id)

  return <TeamManagement teamMembers={teamMembers || []} />
}

