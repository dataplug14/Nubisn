import type { Metadata } from "next"
import { ProfileSettings } from "@/components/profile/profile-settings"
import { createClient } from "@/lib/supabase-server"

export const metadata: Metadata = {
  title: "Profile | Nubis Cloud Console",
  description: "Manage your profile settings",
}

export default async function ProfilePage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Fetch user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user?.id).single()

  return <ProfileSettings user={user} profile={profile} />
}

