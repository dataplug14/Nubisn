import type { Metadata } from "next"
import { SecuritySettings } from "@/components/security/security-settings"

export const metadata: Metadata = {
  title: "Security | Nubis Cloud Console",
  description: "Manage your security settings",
}

export default function SecurityPage() {
  return <SecuritySettings />
}

