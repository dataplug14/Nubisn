"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { CreditCard, Download, Plus } from "lucide-react"

interface Billing {
  balance: number
  used: number
}

interface Payment {
  id: string
  amount: number
  status: string
  payment_method: string
  created_at: string
}

export function BillingManagement({
  billing,
  payments,
}: {
  billing: Billing
  payments: Payment[]
}) {
  const { toast } = useToast()
  const [isProcessing, setIsProcessing] = useState(false)

  const handleAddFunds = (amount: number) => {
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      toast({
        title: "Redirecting to Paystack",
        description: `You'll be redirected to complete your payment of ₦${amount.toLocaleString()}.`,
      })

      // In a real implementation, this would redirect to Paystack
      window.open("https://paystack.com", "_blank")

      setIsProcessing(false)
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Billing & Payments</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Account Balance</CardTitle>
            <CardDescription>Your current account balance and usage</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">Available Balance</div>
              <div className="text-3xl font-bold">₦{billing.balance.toLocaleString()}</div>
            </div>

            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">Used Balance</div>
              <div className="text-xl">₦{billing.used.toLocaleString()}</div>
            </div>

            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">Billing Model</div>
              <div className="text-base">Pay-as-you-go (Per Hour)</div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={() => handleAddFunds(10000)} disabled={isProcessing}>
              <Plus className="mr-2 h-4 w-4" />
              {isProcessing ? "Processing..." : "Add Funds"}
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add Funds</CardTitle>
            <CardDescription>Select an amount to add to your account</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {[5000, 10000, 20000, 50000, 100000, 200000].map((amount) => (
                <Button
                  key={amount}
                  variant="outline"
                  className="h-auto flex flex-col items-center justify-center p-4"
                  onClick={() => handleAddFunds(amount)}
                  disabled={isProcessing}
                >
                  <span className="text-lg font-bold">₦{amount.toLocaleString()}</span>
                </Button>
              ))}
            </div>
          </CardContent>
          <CardFooter className="text-sm text-muted-foreground">
            Payments are processed securely via Paystack
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="history">
        <TabsList>
          <TabsTrigger value="history">Payment History</TabsTrigger>
          <TabsTrigger value="methods">Payment Methods</TabsTrigger>
        </TabsList>

        <TabsContent value="history" className="space-y-4">
          {payments.length > 0 ? (
            <div className="rounded-lg border">
              <div className="grid grid-cols-12 gap-4 p-4 text-sm font-medium text-muted-foreground">
                <div className="col-span-3">Date</div>
                <div className="col-span-3">Amount</div>
                <div className="col-span-3">Payment Method</div>
                <div className="col-span-2">Status</div>
                <div className="col-span-1 text-right">Receipt</div>
              </div>

              {payments.map((payment) => (
                <div key={payment.id} className="grid grid-cols-12 gap-4 border-t p-4 text-sm">
                  <div className="col-span-3">{new Date(payment.created_at).toLocaleDateString()}</div>
                  <div className="col-span-3 font-medium">₦{payment.amount.toLocaleString()}</div>
                  <div className="col-span-3 capitalize">{payment.payment_method}</div>
                  <div className="col-span-2">
                    <div
                      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        payment.status === "successful"
                          ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                          : payment.status === "pending"
                            ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                            : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                      }`}
                    >
                      {payment.status}
                    </div>
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        toast({
                          title: "Receipt Downloaded",
                          description: "Your receipt has been downloaded.",
                        })
                      }}
                    >
                      <Download className="h-4 w-4" />
                      <span className="sr-only">Download</span>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>No Payment History</CardTitle>
                <CardDescription>You haven't made any payments yet.</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center space-y-4 p-6 text-center">
                <div className="rounded-full bg-primary/10 p-3">
                  <CreditCard className="h-6 w-6 text-primary" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold">Add Funds to Get Started</h3>
                  <p className="text-muted-foreground">
                    Add funds to your account to start using Nubis Cloud services.
                  </p>
                </div>
                <Button onClick={() => handleAddFunds(10000)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Funds
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="methods">
          <Card>
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
              <CardDescription>Manage your payment methods</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <CreditCard className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">Paystack</div>
                        <div className="text-sm text-muted-foreground">Naira payments only</div>
                      </div>
                    </div>
                    <div className="text-sm font-medium text-green-600 dark:text-green-400">Active</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

