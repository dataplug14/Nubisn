"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase-browser"

const formSchema = z.object({
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  lastName: z.string().min(2, {
    message: "Last name must be at least 2 characters.",
  }),
  companyName: z.string().optional(),
  phoneNumber: z.string().optional(),
  projectName: z.string().min(3, {
    message: "Project name must be at least 3 characters.",
  }),
  projectDescription: z.string().optional(),
})

export function OnboardingForm({ userId }: { userId: string }) {
  const router = useRouter()
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const supabase = createClient()

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      companyName: "",
      phoneNumber: "",
      projectName: "My First Project",
      projectDescription: "",
    },
  })

  const steps = ["profile", "project", "billing"]

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (currentStep < steps.length - 1) {
      nextStep()
      return
    }

    setIsSubmitting(true)

    try {
      // Update user profile
      const { error: profileError } = await supabase.from("profiles").upsert({
        id: userId,
        first_name: values.firstName,
        last_name: values.lastName,
        company_name: values.companyName || null,
        phone_number: values.phoneNumber || null,
        onboarding_completed: true,
      })

      if (profileError) {
        throw profileError
      }

      // Create first project
      const { error: projectError } = await supabase.from("projects").insert({
        user_id: userId,
        name: values.projectName,
        description: values.projectDescription || null,
      })

      if (projectError) {
        throw projectError
      }

      toast({
        title: "Onboarding Complete",
        description: "Your account has been set up successfully.",
      })

      // Redirect to dashboard
      router.push("/dashboard")
      router.refresh()
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to complete onboarding",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Tabs value={steps[currentStep]} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile" disabled={currentStep !== 0}>
              Profile
            </TabsTrigger>
            <TabsTrigger value="project" disabled={currentStep !== 1}>
              Project
            </TabsTrigger>
            <TabsTrigger value="billing" disabled={currentStep !== 2}>
              Billing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6 pt-4">
            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="companyName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company Name (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Acme Inc." {...field} />
                    </FormControl>
                    <FormDescription>Enter your company name if applicable.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="+1234567890" {...field} />
                    </FormControl>
                    <FormDescription>For account recovery and notifications.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </TabsContent>

          <TabsContent value="project" className="space-y-6 pt-4">
            <FormField
              control={form.control}
              name="projectName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Name</FormLabel>
                  <FormControl>
                    <Input placeholder="My First Project" {...field} />
                  </FormControl>
                  <FormDescription>Give your first project a name.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="projectDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Description (Optional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe your project..." className="resize-none" rows={4} {...field} />
                  </FormControl>
                  <FormDescription>A brief description of your project's purpose.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>

          <TabsContent value="billing" className="space-y-6 pt-4">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-lg font-medium">Add Funds to Your Account</h3>
                    <p className="text-sm text-muted-foreground">
                      You'll need to add funds to your account to start using Nubis Cloud services.
                    </p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    {[5000, 10000, 20000].map((amount) => (
                      <Button
                        key={amount}
                        variant="outline"
                        className="h-auto flex flex-col items-center justify-center p-4"
                        type="button"
                        onClick={() => {
                          toast({
                            title: "Redirecting to Payment",
                            description: `You'll be redirected to Paystack to add ₦${amount.toLocaleString()} to your account.`,
                          })
                        }}
                      >
                        <span className="text-2xl font-bold">₦{amount.toLocaleString()}</span>
                        <span className="text-sm text-muted-foreground">Add to balance</span>
                      </Button>
                    ))}
                  </div>

                  <p className="text-sm text-muted-foreground text-center">
                    You can skip this step and add funds later.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between">
          <Button type="button" variant="outline" onClick={prevStep} disabled={currentStep === 0}>
            Previous
          </Button>

          <Button type="submit" disabled={isSubmitting}>
            {currentStep === steps.length - 1 ? (isSubmitting ? "Completing..." : "Complete Setup") : "Next"}
          </Button>
        </div>
      </form>
    </Form>
  )
}

